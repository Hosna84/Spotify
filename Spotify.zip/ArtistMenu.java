import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ArtistMenu {
    private static int flagForInvalid;

    public static void run(Scanner scanner) {
        while (true) {
            flagForInvalid = 0;
            String input = scanner.nextLine();
            if (input.trim().equals("back"))
                break;
            if (input.equals("show menu name")) {
                System.out.println("artist menu");
                flagForInvalid = 1;
            }
            if (input.trim().equals("show tracks")) {
                flagForInvalid = 1;
                showTracks();

            }
            if (input.trim().equals("show songs")) {

                flagForInvalid = 1;
                showSongs();
            }
            if (input.equals("show podcasts")) {
                flagForInvalid = 1;
                showPodcasts();
            }
            if (input.contains("release -n")) {
                flagForInvalid = 1;
                String regex = "release -n (?<trackName>[a-zA-Z0-9 ]+) -t (?<type>song|podcast) -d (?<duration>[0-9]+) -r (?<releaseDate>\\d{4}/\\d{2}/\\d{2})";
                Matcher matcher = getCommandMatcher(input, regex);
                releaseTrack(matcher);
            }
            if (input.equals("num of followers")) {
                flagForInvalid = 1;
                getNumberOfFollowers();
            }
            if (input.equals("get rank")) {
                flagForInvalid = 1;
                getRank();
            } else if (flagForInvalid == 0) System.out.println("invalid command");


        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    private static void showTracks() {
        Artist artist = Artist.getLoggedInArtist();
        if (artist != null) {
            ArrayList<Track> tracks = artist.getTracks();
            Collections.sort(tracks, Comparator.comparing(Track::getReleaseDate).reversed()
                    .thenComparing(Track::getName));
            for (Track obj : tracks) {
                System.out.println(obj.getName());
            }
        }
    }


    private static void showSongs() {
        Artist artist = Artist.getLoggedInArtist();
        if (artist != null) {

            ArrayList<Track> tracks = artist.getTracks();
            Collections.sort(tracks, Comparator.comparing(Track::getType).reversed()
                    .thenComparing(Track::getReleaseDate).reversed()
                    .thenComparing(Track::getName));
            for (Track obj : tracks) {
                if (obj.getType()) {
                    System.out.println(obj.getName());
                }
            }
        }
    }

    private static void showPodcasts() {
        Artist artist = Artist.getLoggedInArtist();
        if (artist != null) {
            ArrayList<Track> tracks = artist.getTracks();
            Collections.sort(tracks, Comparator.comparing(Track::getType).reversed()
                    .thenComparing(Track::getReleaseDate).reversed()
                    .thenComparing(Track::getName));
            for (Track obj : tracks) {
                if (!obj.getType()) {
                    System.out.println(obj.getName());
                }
            }
        }
    }

    private static void releaseTrack(Matcher matcher) {
        if (matcher.matches()) {

            String trackName = matcher.group("trackName");
            String type = matcher.group("type");
            int duration = Integer.parseInt(matcher.group("duration"));
            String releaseDate = matcher.group("releaseDate");
            if (Track.getTrackByName(trackName) != null) System.out.println("track name already exists");
            else {
                boolean typeForSongOrPodcast = true;
                if (type.equals("podcast")) typeForSongOrPodcast = false;
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                LocalDate datee = LocalDate.parse(releaseDate, formatter);
                Date date = Date.from(datee.atStartOfDay(ZoneId.systemDefault()).toInstant());

                Track track = new Track(date, Artist.getLoggedInArtist(), typeForSongOrPodcast, duration, trackName);
                Track.addTrack(track);
                if ((Artist.getLoggedInArtist()) != null)
                    Artist.getLoggedInArtist().addToTotalTracks(track);
                System.out.println("track released successfully");
            }

        } else {
            flagForInvalid = 1;
            System.out.println("invalid command");
        }
    }

    private static void getNumberOfFollowers() {
        Artist artist = Artist.getLoggedInArtist();
        if (artist != null)
            System.out.println(artist.getFollowers());
    }

    private static void getRank() {
       Artist.rankObjects (Artist.getArtists());
        Artist artist = Artist.getLoggedInArtist();
        if (artist != null)
            System.out.println(artist.getRank());
    }
}
