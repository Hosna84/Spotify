import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PlaylistMenu {
    private static int flagForInvalid;

    public static void run(Scanner scanner) {
        while (true) {
            flagForInvalid = 0;
            String input = scanner.nextLine();
            if (input.trim().equals("back"))
                break;
            if (input.equals("show menu name")) {
                System.out.println("playlist menu");
                flagForInvalid = 1;
            }
            if (input.trim().trim().equals("show tracks")) {
                flagForInvalid = 1;
                showTracks();
            }
            if (input.equals("show duration")) {
                flagForInvalid = 1;
                showDuration();
            }
            if (input.contains("add -t")) {
                flagForInvalid = 1;
                String regex = "add -t (?<trackName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                addTrack(matcher);
            }
            if (input.contains("remove -t")) {
                flagForInvalid = 1;
                String regex = "remove -t (?<trackName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                removeTrack(matcher);
            } else if (flagForInvalid == 0)
                System.out.println("invalid command");

        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    private static void showTracks() {
        Playlist playlist = Playlist.getCurrecntPlaylist();
        ArrayList<Track> tracks = playlist.getTracks();
        Collections.sort(tracks, Comparator.comparing(Track::getReleaseDate).reversed()
                .thenComparing(Track::getName));

        for (Track obj : tracks) {
            System.out.println(obj.getName());
        }
    }

    private static void showDuration() {
        Playlist playlist = Playlist.getCurrecntPlaylist();
        System.out.println(playlist.getTotalTracks());
    }

    private static void addTrack(Matcher matcher) {

        if (matcher.matches()) {
            String trackName = matcher.group("trackName");
            Track track = Track.getTrackByName(trackName);
            if (!(User.getLoggedInUser().equals(Playlist.getCurrecntPlaylist().getOwner()))) {
                System.out.println("user doesn't own this playlist");
            } else if (!(Track.getTracks().contains(track))) {
                System.out.println("no such track");
            } else if (Playlist.getCurrecntPlaylist().getTracks().contains(track)) {
                System.out.println("track is already in the playlist");
            } else {
                Playlist.getCurrecntPlaylist().addTrack(track);
                System.out.println("track added to playlist successfully");
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void removeTrack(Matcher matcher) {
        if (matcher.matches()) {
            String trackName = matcher.group("trackName");
            Playlist playlist = Playlist.getCurrecntPlaylist();
            ArrayList<Track> tracks = playlist.getTracks();
            if (!(tracks.contains(Track.getTrackByName(trackName)))) {
                System.out.println("no such track in playlist");
            } else {
                playlist.removeTrack(Track.getTrackByName(trackName));
                System.out.println("track removed from playlist successfully");
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }
}

