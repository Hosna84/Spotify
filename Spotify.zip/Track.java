import java.util.ArrayList;
import java.util.Date;

public class Track {
    private String name;
    private Artist artist;
    private int duration;
    private static ArrayList<Track> tracks = new ArrayList<>();
    private Date releaseDate;
    private boolean type;

    public String getName() {
        return this.name;
    }

    public Track(Date releaseDate, Artist artist, boolean type, int duration, String name) {
        this.releaseDate = releaseDate;
        this.artist = artist;
        this.type = type;
        this.duration = duration;
        this.name = name;

    }

    public Artist getArtist() {
        return this.artist;
    }

    public int getDuration() {
        return this.duration;
    }

    public Date getReleaseDate() {
        return this.releaseDate;
    }

    public boolean getType() {
        return this.type;
    }

    public static void addTrack(Track track) {
        tracks.add(track);
    }

    public static ArrayList<Track> getTracks() {
        return tracks;
    }


    public static Track getTrackByName(String name) {
        for (int g = 0; g < tracks.size(); g++) {
            if (tracks.get(g).getName().equals(name)) {
                return tracks.get(g);
            }
        }
        return null;
    }


}
