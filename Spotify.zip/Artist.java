import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Artist {
    private String userName;
    private String password;
    private String nickname;
    private int followers;
    private int rank;
    private ArrayList<Track> tracks = new ArrayList<>();
    private static Artist loggedInArtist;
    private static ArrayList<Artist> artists = new ArrayList<>();

    public Artist(String username, String password, String nickname) {
        this.userName = username;
        this.password = password;
        this.nickname = nickname;

    }

    public static void addArtist(Artist artist) {
        artists.add(artist);
        rankObjects(artists);
    }

    public static Artist getArtistByUsername(String username) {

        for (int j = 0; j < artists.size(); j++) {
            if (username.equals(artists.get(j).userName)) {
                return artists.get(j);
            }
        }

        return null;
    }

    public String getPassword() {
        return this.password;
    }


    public String getUserName() {
        return this.userName;
    }

    public String getNickname() {
        return this.nickname;
    }

    public int getFollowers() {
        return this.followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public ArrayList getTracks() {
        return this.tracks;
    }

    public void addToTotalTracks(Track track) {
        tracks.add(track);
    }

    public static Artist getLoggedInArtist() {
        return loggedInArtist;

    }

    public static void setLoggedInArtist(Artist artist) {
        loggedInArtist = artist;
    }

    public static ArrayList<Artist> getArtists() {
        return artists;
    }

    public static void rankObjects(ArrayList<Artist> artists) {
        for (int j = 0; j < artists.size(); j++) {
            int isMore = 1;
            int currentFollowers = artists.get(j).getFollowers();


            for (int i = 0; i < artists.size(); i++) {
                Artist currentArtist = artists.get(i);
                if (currentArtist.getFollowers() > currentFollowers) {

                    isMore++;
                }


            }
            artists.get(j).setRank(isMore);

        }
    }


    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getRank() {
        return this.rank;
    }

}
