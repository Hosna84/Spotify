import java.util.ArrayList;

public class Playlist {
    private String name;
    private User owner;
    private int totalTracks;
    private ArrayList<Track> tracks = new ArrayList<>();
    private static ArrayList<Playlist> playlists = new ArrayList<>();
    private static Playlist currecntPlaylist;

    public Playlist(String name, User owner) {
        this.name = name;
        this.owner = owner;
        this.totalTracks = 0;
    }

    public void addTrack(Track track) {
        tracks.add(track);
        this.totalTracks += track.getDuration();
    }

    public void removeTrack(Track track) {
        tracks.remove(track);
        this.totalTracks -= track.getDuration();
    }

    public User getOwner() {
        return this.owner;
    }

    public String getName() {
        return this.name;
    }

    public ArrayList<Track> getTracks() {
        return this.tracks;
    }

    public int getTotalTracks() {
        return this.totalTracks;
    }

    public static void addPlaylist(Playlist playlist) {
        playlists.add(playlist);
    }

    public static void removePlaylist(Playlist playlist) {
        playlists.remove(playlist);
    }

    public static Playlist getPlaylistByName(String name) {
        for (int i = 0; i < playlists.size(); i++) {
            if (playlists.get(i).getName().equals(name)) {
                return playlists.get(i);
            }
        }
        return null;
    }

    public static Playlist getCurrecntPlaylist() {
        return currecntPlaylist;
    }

    public static void setCurrecntPlaylist(Playlist playlist) {
        currecntPlaylist = playlist;
    }

}

