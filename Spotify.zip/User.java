import java.util.ArrayList;

public class User {

    private String username;
    private String password;
    private int followers;
    private int following;
    private ArrayList<Track> queue = new ArrayList<>();
    private ArrayList<Track> likedTracks = new ArrayList<>();
    private ArrayList<Playlist> playlists = new ArrayList<>();
    private static User loggedinUser;
    private static ArrayList<User> users = new ArrayList<>();


    public User(String userName, String password) {
        this.username = userName;
        this.password = password;

    }

    public String getPassword() {
        return this.password;
    }

    public static void addUser(User user) {
        users.add(user);
    }

    public static ArrayList getUsers() {
        return users;
    }

    public String getUsername() {
        return this.username;
    }

    public static User getLoggedInUser() {
        return loggedinUser;
    }

    public static void setLoggedinUser(User user) {
        loggedinUser = user;
    }

    public int getFollowing() {
        return this.following;
    }

    public int getFollowers() {
        return this.followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public void setFollowing(int following) {
        this.following = following;
    }

    public void addPlaylist(Playlist playlist) {
        playlists.add(playlist);
    }

    public void removePlaylist(Playlist playlist) {
        playlists.remove(playlist);
    }

    public void addToQueue(Track track) {
        queue.add(track);
    }

    public void removefromQueue(Track track) {
        queue.removeIf(currentTrack -> currentTrack.getName().equals(track.getName()));
    }

    public void addLikedTrack(Track track) {
        likedTracks.add(track);
    }

    public void removeLikedTrack(Track track) {
        likedTracks.remove(track);
    }

    public static User getUserByUsername(String username) {
        for (int q = 0; q < users.size(); q++) {
            if (users.get(q).getUsername().equals(username)) {
                return users.get(q);
            }
        }
        return null;
    }

    public ArrayList getQueue() {
        return this.queue;
    }

    public void setQueue(ArrayList<Track> queue) {
        this.queue = queue;
    }

    public ArrayList getPlaylists() {
        return this.playlists;
    }

    public ArrayList getLikedTrack() {

        return this.likedTracks;
    }


}
