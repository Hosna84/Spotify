
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class UserMenu {
    private static int flagForInvalid;

    public static void run(Scanner scanner) {

        while (true) {

            flagForInvalid = 0;
            String input = scanner.nextLine();

            if (input.trim().equals("back"))
                break;
            if (input.equals("show menu name")) {
                System.out.println("user menu");
                flagForInvalid = 1;
            }
            if (input.trim().equals("show playlists")) {

                flagForInvalid = 1;
                showPlaylists();

            }
            if (input.equals("show liked tracks")) {
                flagForInvalid = 1;
                showLikedTracks();
            }
            if (input.equals("show queue")) {
                flagForInvalid = 1;
                showQueue();
            }
            if (input.contains("add -t")) {
                flagForInvalid = 1;
                String regex = "add -t (?<trackname>[a-zA-Z0-9 ]+) to queue";
                Matcher matcher = getCommandMatcher(input, regex);
                addTrackToQueue(matcher);

            }
            if (input.contains("like track -t")) {
                flagForInvalid = 1;
                String regex = "like track -t (?<trackname>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                addTrackToLikedTracks(matcher);
            }
            if (input.contains("from queue")) {
                flagForInvalid = 1;
                String regex = "remove -t (?<trackname>[a-zA-Z0-9 ]+) from queue";
                Matcher matcher = getCommandMatcher(input, regex);
                removeFromQueue(matcher);

            }
            if (input.contains("from liked tracks")) {
                flagForInvalid = 1;
                String regex = "remove -t (?<trackname>[a-zA-Z0-9 ]+) from liked tracks";
                Matcher matcher = getCommandMatcher(input, regex);
                removeFromLikedTracks(matcher);

            }
            if (input.contains("reverse order of queue from")) {
                flagForInvalid = 1;
                String regex = "reverse order of queue from (?<start>-?\\d+) to (?<end>-?\\d+)";
                Matcher matcher = getCommandMatcher(input, regex);
                reserveOrderOfQueue(matcher);
            }
            if (input.contains("create -p")) {
                flagForInvalid = 1;
                String regex = "create -p (?<playlistName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                createPlaylist(matcher);

            }
            if (input.contains("delete -p")) {

                flagForInvalid = 1;
                String regex = "delete -p (?<playlistName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                removePlaylist(matcher);
            }
            if (input.startsWith("follow user -u")) {

                flagForInvalid = 1;
                String regex = "follow user -u (?<username>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                followUser(matcher);
            }
            if (input.startsWith("follow artist -u")) {

                flagForInvalid = 1;
                String regex = "follow artist -u (?<username>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                followArtist(matcher);
            }
            if (input.contains("unfollow user -u")) {
                flagForInvalid = 1;
                String regex = "unfollow user -u (?<username>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                unfollowUser(matcher);
            }
            if (input.contains("unfollow artist -u")) {
                flagForInvalid = 1;
                String regex = "unfollow artist -u (?<username>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                unfollowArtist(matcher);
            }
            if (input.contains("go to playlist menu -p")) {
                flagForInvalid = 1;
                String regex = "go to playlist menu -p (?<playlistName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                goToPlaylistMenu(matcher, scanner);
            }
            if (input.contains("show track info -t")) {
                flagForInvalid = 1;
                String regex = "show track info -t (?<trackName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                showTrackInfo(matcher);

            }
            if (input.contains("show playlist info -p")) {
                flagForInvalid = 1;
                String regex = "show playlist info -p (?<playlistName>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                showPlaylistInfo(matcher);
            }
            if (input.startsWith("show artist info -u")) {

                flagForInvalid = 1;
                String regex = "show artist info -u (?<username>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                showArtistInfo(matcher);
            }
            if (input.contains("show user info -u")) {
                flagForInvalid = 1;
                String regex = "show user info -u (?<username>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                showUserInfo(matcher);
            } else if (flagForInvalid == 0) {
                System.out.println("invalid command");
            }
        }

    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    private static void showPlaylists() {
        ArrayList<Playlist> playlists = User.getLoggedInUser().getPlaylists();

        ArrayList<String> copyPlaylistnames = new ArrayList<>();
        for (int u = 0; u < playlists.size(); u++) {
            copyPlaylistnames.add(playlists.get(u).getName());
        }
        Collections.sort(copyPlaylistnames);
        for (int f = 0; f < copyPlaylistnames.size(); f++) {
            System.out.println(copyPlaylistnames.get(f));
        }
    }

    private static void showLikedTracks() {
        ArrayList<Track> likedTracks = User.getLoggedInUser().getLikedTrack();
        ArrayList<String> copyLikedTracks = new ArrayList<>();
        for (int d = 0; d < likedTracks.size(); d++) {
            copyLikedTracks.add(likedTracks.get(d).getName());
        }
        Collections.sort(copyLikedTracks);
        for (int h = 0; h < copyLikedTracks.size(); h++) {
            System.out.println(copyLikedTracks.get(h));
        }
    }

    private static void showQueue() {
        ArrayList<Track> queue = User.getLoggedInUser().getQueue();
        for (int g = 0; g < queue.size(); g++) {
            System.out.println(queue.get(g).getName());
        }
    }

    private static void addTrackToQueue(Matcher matcher) {
        if (matcher.matches()) {
            String trackName = matcher.group("trackname");
            if (Track.getTrackByName(trackName) == null) {
                System.out.println("no such track");

            } else {
                User.getLoggedInUser().addToQueue(Track.getTrackByName(trackName));
                System.out.println("track added to queue successfully");
            }

        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }

    }

    private static void addTrackToLikedTracks(Matcher matcher) {
        if (matcher.matches()) {
            String trackName = matcher.group("trackname");
            if (Track.getTrackByName(trackName) == null) {
                System.out.println("no such track");

            } else if (User.getLoggedInUser().getLikedTrack().contains(Track.getTrackByName(trackName))) {
                System.out.println("track is already liked");

            } else {
                User.getLoggedInUser().addLikedTrack(Track.getTrackByName(trackName));
                System.out.println("liked track successfully");
            }

        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void removeFromQueue(Matcher matcher) {
        if (matcher.matches()) {
            String trackName = matcher.group("trackname");
            User user = User.getLoggedInUser();
            boolean flag = false;
            while (user.getQueue().contains(Track.getTrackByName(trackName))) {
                flag = true;
                user.getQueue().remove(Track.getTrackByName(trackName));
            }
            if (flag) {
                System.out.println("track removed from queue successfully");
            } else System.out.println("no such track in queue");

        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void removeFromLikedTracks(Matcher matcher) {
        if (matcher.matches()) {
            String trackName = matcher.group("trackname");
            if (!(User.getLoggedInUser().getLikedTrack().contains(Track.getTrackByName(trackName)))) {
                System.out.println("no such track in liked tracks");

            } else {
                User.getLoggedInUser().removeLikedTrack(Track.getTrackByName(trackName));
                System.out.println("track removed from liked tracks successfully");

            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void reserveOrderOfQueue(Matcher matcher) {
        if (matcher.matches()) {
            String start = matcher.group("start");
            String end = matcher.group("end");
            int startFrom = Integer.parseInt(start);
            int endIn = Integer.parseInt(end);
            if (User.getLoggedInUser().getQueue().size() == 0) {
                System.out.println("queue is empty");
            } else if (start.contains("-") || end.contains("-") ||
                    !(startFrom >= 1 && startFrom <= User.getLoggedInUser().getQueue().size()) ||
                    !(endIn >= 1 && endIn <= User.getLoggedInUser().getQueue().size()) ||
                    startFrom >= endIn) {
                System.out.println("invalid bounds");

            } else {
                startFrom--;
                endIn--;
                if (startFrom >= 0 && endIn >= 0) {
                    while (startFrom < endIn) {
                        Collections.swap(User.getLoggedInUser().getQueue(), startFrom, endIn);
                        startFrom++;
                        endIn--;
                    }
                }
                System.out.println("order of queue reversed successfully");
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void createPlaylist(Matcher matcher) {
        if (matcher.matches()) {
            String playlist = matcher.group("playlistName");

            if (Playlist.getPlaylistByName(playlist) != null) {
                System.out.println("playlist name already exists");
            } else {
                Playlist playlist1 = new Playlist(playlist, User.getLoggedInUser());
                Playlist.addPlaylist(playlist1);
                User.getLoggedInUser().addPlaylist(Playlist.getPlaylistByName(playlist));
                System.out.println("playlist created successfully");
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void removePlaylist(Matcher matcher) {

        if (matcher.matches()) {
            String playlistName = matcher.group("playlistName");
            if (Playlist.getPlaylistByName(playlistName) == null ||
                    !(User.getLoggedInUser().getPlaylists().contains(Playlist.getPlaylistByName(playlistName)))) {
                System.out.println("user doesn't own such playlist");
            } else {
                User.getLoggedInUser().removePlaylist(Playlist.getPlaylistByName(playlistName));
                Playlist.removePlaylist(Playlist.getPlaylistByName(playlistName));
                System.out.println("playlist deleted successfully");
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }

    }

    private static void followUser(Matcher matcher) {
        if (matcher.matches()) {
            String userName = matcher.group("username");
            if (!(User.getUsers().contains(User.getUserByUsername(userName)))) {
                System.out.println("no such user");
            } else if (User.getLoggedInUser().getUsername().equals(userName)) {
                System.out.println("you can't follow yourself");
            } else {
                int newFollowing = User.getLoggedInUser().getFollowing() + 1;
                User.getLoggedInUser().setFollowing(newFollowing);
                int newFollower = User.getUserByUsername(userName).getFollowers() + 1;
                User.getUserByUsername(userName).setFollowers(newFollower);
                System.out.println("added user to followings");
            }


        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void followArtist(Matcher matcher) {
        if (matcher.matches()) {
            String artistname = matcher.group("username");
            if (Artist.getArtistByUsername(artistname) == null) {
                System.out.println("no such artist");
            } else {
                int newFollowing = User.getLoggedInUser().getFollowing() + 1;
                User.getLoggedInUser().setFollowing(newFollowing);

                int newFollowers = Artist.getArtistByUsername(artistname).getFollowers() + 1;
                Artist.getArtistByUsername(artistname).setFollowers(newFollowers);
                System.out.println("added artist to followings");

            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void unfollowUser(Matcher matcher) {

        if (matcher.matches()) {
            String username = matcher.group("username");
            if (!(User.getUsers().contains(User.getUserByUsername(username)))) {
                System.out.println("no such user");
            } else if (User.getLoggedInUser().getUsername().equals(username)) {
                System.out.println("you can't unfollow yourself");
            } else {
                int newFollowing = User.getLoggedInUser().getFollowing() - 1;
                User.getLoggedInUser().setFollowing(newFollowing);
                int newFollower = User.getUserByUsername(username).getFollowers() - 1;
                User.getUserByUsername(username).setFollowers(newFollower);
                if (Artist.getLoggedInArtist() != null)
                    Artist.rankObjects(Artist.getLoggedInArtist().getArtists());
                System.out.println("user unfollowed successfully");
            }

        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void unfollowArtist(Matcher matcher) {

        if (matcher.matches()) {
            String username = matcher.group("username");
            if (Artist.getArtistByUsername(username) == null) {
                System.out.println("no such artist");
            } else {
                int newFollowing = User.getLoggedInUser().getFollowing() - 1;
                User.getLoggedInUser().setFollowing(newFollowing);
                int newFollowers = Artist.getArtistByUsername(username).getFollowers() - 1;
                Artist.getArtistByUsername(username).setFollowers(newFollowers);

                System.out.println("artist unfollowed successfully");
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void goToPlaylistMenu(Matcher matcher, Scanner scanner) {
        if (matcher.matches()) {
            String playlistName = matcher.group("playlistName");
            if (Playlist.getPlaylistByName(playlistName) == null) {
                System.out.println("no such playlist");
            } else {
                Playlist.setCurrecntPlaylist(Playlist.getPlaylistByName(playlistName));
                System.out.println("entered playlist menu successfully");
                PlaylistMenu.run(scanner);

            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void showTrackInfo(Matcher matcher) {
        if (matcher.matches()) {
            String trackName = matcher.group("trackName");
            if (!(Track.getTracks().contains(Track.getTrackByName(trackName)))) {
                System.out.println("no such track");
            } else {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                String trackType = "";
                if (Track.getTrackByName(trackName).getType() == true) trackType = "song";
                else trackType = "podcast";
                System.out.println(trackName + " " + trackType + " " + Track.getTrackByName(trackName).getDuration() +
                        " " + dateFormat.format(Track.getTrackByName(trackName).getReleaseDate()) +
                        " " + Track.getTrackByName(trackName).getArtist().getNickname());
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void showPlaylistInfo(Matcher matcher) {
        if (matcher.matches()) {
            String playlist = matcher.group("playlistName");
            if (Playlist.getPlaylistByName(playlist) == null) {
                System.out.println("no such playlist");
            } else {
                Playlist playlist1 = Playlist.getPlaylistByName(playlist);

                System.out.println(playlist1.getName() + " " + playlist1.getOwner().getUsername() + " " + playlist1.getTotalTracks());
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    private static void showArtistInfo(Matcher matcher) {
        if (matcher.matches()) {
            String artistName = matcher.group("username");

            Artist artist = Artist.getArtistByUsername(artistName);

            if (artist == null) {
                System.out.println("no such artist ");
            } else {


                if (Artist.getArtists() != null)
                    Artist.rankObjects(Artist.getArtists());
                System.out.println(artist.getUserName() + " " + artist.getNickname() + " " + artist.getFollowers() + " " + artist.getRank());
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

    public static void showUserInfo(Matcher matcher) {

        if (matcher.matches()) {
            String userName = matcher.group("username");
            if (!(User.getUsers().contains(User.getUserByUsername(userName)))) {
                System.out.println("no such user");
            } else {
                User user = User.getUserByUsername(userName);
                System.out.println(user.getUsername() + " " + user.getFollowers() + " " + user.getFollowing() + " " + user.getPlaylists().size());
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }
    }

}
