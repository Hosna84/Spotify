import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenu {

    private static int flagForInvalid;

    public static void run(Scanner scanner) {
        while (true) {
            flagForInvalid = 0;
            String input = scanner.nextLine();

            if (input.trim().equals("exit"))
                break;


            if (input.equals("show menu name")) {
                System.out.println("login menu");
                flagForInvalid = 1;
            }
            if (input.contains("register as user")) {
                flagForInvalid = 1;
                String regex = "register as user -u (?<username>[a-zA-Z0-9]+) -p (?<password>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);


                userReister(matcher);


            }
            if (input.contains("register as artist")) {
                flagForInvalid = 1;
                String regex = "register as artist -u (?<username>[a-zA-Z0-9]+) -p (?<password>[a-zA-Z0-9]+) -n (?<nickname>[a-zA-Z0-9 ]+)";
                Matcher matcher = getCommandMatcher(input, regex);


                artistRegister(matcher);


            }
            if (input.contains("login as user")) {
                flagForInvalid = 1;
                String regex = "login as user -u (?<username>[a-zA-Z0-9]+) -p (?<password>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                userLogin(matcher, scanner);

            }
            if (input.contains("login as artist")) {
                flagForInvalid = 1;
                String regex = "login as artist -u (?<username>[a-zA-Z0-9]+) -p (?<password>[a-zA-Z0-9]+)";
                Matcher matcher = getCommandMatcher(input, regex);
                artistLogin(matcher, scanner);
            } else if (flagForInvalid == 0) System.out.println("invalid command");
        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    private static boolean isPasswordWeak(String password1) {

        String regex = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcherForPass = pattern.matcher(password1);

        return matcherForPass.find();
    }

    private static void userReister(Matcher matcher) {
        if (matcher.matches()) {
            String userName = matcher.group("username");
            String password = matcher.group("password");
            ArrayList<User> users = User.getUsers();
            int flag = 1;
            for (int i = 0; i < users.size(); i++) {
                if (userName.equals(users.get(i).getUsername())) {
                    System.out.println("username already exists");
                    flag = 0;
                    break;
                }
            }
            if (!isPasswordWeak(password) && flag == 1) {
                System.out.println("password is not strong enough");
                flag = 0;
            }
            if (flag == 1) {
                User user = new User(userName, password);
                User.addUser(user);
                System.out.println("user registered successfully");
            }
        } else {
            flagForInvalid = 1;
            System.out.println("invalid command");
        }
    }

    private static void artistRegister(Matcher matcher) {
        if (matcher.matches()) {
            int flag = 1;
            String userName = matcher.group("username");
            String password = matcher.group("password");
            String nickName = matcher.group("nickname");

            Artist artist = Artist.getArtistByUsername(userName);
            if (artist != null) {
                System.out.println("username already exists");
                flag = 0;
            }
            if (!isPasswordWeak(password) && flag == 1) {
                System.out.println("password is not strong enough");
                flag = 0;

            } else if (flag == 1) {
                Artist artist1 = new Artist(userName, password, nickName);
                Artist.addArtist(artist1);
                System.out.println("artist registered successfully");

            }
        } else {
            flagForInvalid = 1;
            System.out.println("invalid command");
        }

    }

    private static void userLogin(Matcher matcher, Scanner scanner) {
        int flagForUserName = 0;
        int flagForPassword = 0;

        if (matcher.matches()) {
            String username = matcher.group("username");
            String password = matcher.group("password");
            ArrayList<User> users = User.getUsers();
            if (users != null) {
                int indexOfUser = 0;
                for (int j = 0; j < users.size(); j++) {
                    if (users.get(j).getUsername().equals(username)) {
                        flagForUserName = 1;
                        indexOfUser = j;
                        break;
                    }
                }
                if (flagForUserName == 0) {
                    System.out.println("username doesn't exist");
                }

                if (indexOfUser < users.size()) {
                    if (users.get(indexOfUser).getPassword().equals(password))
                        flagForPassword = 1;
                }
                if (flagForUserName == 1 && flagForPassword == 0) System.out.println("password is wrong");
                else if (flagForPassword == 1 && flagForUserName == 1) {
                    User.setLoggedinUser(users.get(indexOfUser));
                    System.out.println("user logged in successfully");
                    UserMenu.run(scanner);
                }
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }

    }

    private static void artistLogin(Matcher matcher, Scanner scanner) {

        if (matcher.matches()) {
            int flag = 0;
            String username = matcher.group("username");
            String password = matcher.group("password");
            Artist artist = Artist.getArtistByUsername(username);

            if (artist == null) {
                System.out.println("username doesn't exist");
                flag = 1;
            }
            if (artist != null && !(artist.getPassword().equals(password))) {
                flag = 1;
                System.out.println("password is wrong");
            } else if (flag == 0) {
                artist.setLoggedInArtist(artist);
                System.out.println("artist logged in successfully");
                ArtistMenu.run(scanner);
            }
        } else {
            System.out.println("invalid command");
            flagForInvalid = 1;
        }


    }
}
